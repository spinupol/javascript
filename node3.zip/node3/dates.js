var Holidays = require('date-holidays')
var hd = new Holidays()
var fs = require('fs');
var csv = require('ya-csv');

var toMmDdYy = function(input) {
    var ptrn = /(\d{4})\-(\d{2})\-(\d{2})/;
    if (!input || !input.match(ptrn)) {
        return null;
    }
    return input.replace(ptrn, '$2$3$1');
};

if (fs.existsSync(__dirname + '/file_with_headers_and_quotes.csv')) {
    fs.unlinkSync(__dirname + '/file_with_headers_and_quotes.csv');
}
if (fs.existsSync(__dirname + '/plain_file_without_header_and_quotes.csv')) {
    fs.unlinkSync(__dirname + '/plain_file_without_header_and_quotes.csv');
}


var writer = csv.createCsvStreamWriter(fs.createWriteStream('file_with_headers_and_quotes.csv', { 'flags': 'a' }));
writer.writeRecord(['Date', 'Name', 'Finra'])
var years = [];
for (var i = 1999; i <= 2020; i++) {
    years.push(i);
}
//console.log(years);

for (var j = 0; j < years.length; j++) {
    hd = new Holidays('US', 'la', 'no')
    var hol = hd.getHolidays(years[j])
    console.log(hol)
    for (var i = 0; i < hol.length; i++) {
        if (hol[i].type == 'public' && (hol[i].name.match(/New*|Martin*|Washing*|Good*|Memo*|Ind*|Lab*|Thanks*|Chris*/))) {
            var today = new Date(hol[i].date);
            if (today.getDay() != 6 && today.getDay() != 0) {
                var str = hol[i].date;
                //console.log(toMmDdYy(str.substring(0, str.length - 8)), hol[i].name.replace(' (substitute day)', ''), hol[i].type)
                writer.writeRecord([toMmDdYy(str.substring(0, str.length - 9)), hol[i].name.replace(' (substitute day)', ''), 'Finra Holiday']);
                fs.appendFile(__dirname + '/plain_file_without_header_and_quotes.csv', toMmDdYy(str.substring(0, str.length - 9)) + '|' + hol[i].name.replace(' (substitute day)', '') + '|' + 'Finra Holiday\n', function(err) {});
            }
        }
    }
}